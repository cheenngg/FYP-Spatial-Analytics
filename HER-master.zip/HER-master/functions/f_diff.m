function [diff] = f_diff(ObsA, ObsB)
%Calculate the difference between 2 observations
%   ObsA,ObsB = observed value (it can be a vector)

diff = ObsA-ObsB;

end

